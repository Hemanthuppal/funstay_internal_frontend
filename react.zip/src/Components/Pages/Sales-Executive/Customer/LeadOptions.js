import React, { useState } from "react";
import { Row, Col, Card, Accordion } from "react-bootstrap";
import "../Potentialleads/OppDetails/LeadDetails.css";
import Navbar from "../../../Shared/Sales-ExecutiveNavbar/Navbar";
import { FaPhone, FaEnvelope } from "react-icons/fa"; // Import FontAwesome icons
import { Form, Dropdown, Button } from "react-bootstrap"; // Import Bootstrap components

const LeadOppView = () => {
        const [collapsed, setCollapsed] = useState(false);

        return (
                <div className="salesViewLeadsContainer">
                        <Navbar onToggleSidebar={setCollapsed} />
                        <div className={`salesViewLeads ${collapsed ? "collapsed" : ""}`}>
                                <div className="lead-opportunity-view">
                                        <Card className="mb-4">
                                                <Card.Header className="s-LeadOppView-modal-header">
                                                        <h2>Customer and Opportunity Details</h2>
                                                </Card.Header>
                                                <Card.Body>
                                                        <Row>
                                                                {/* Customer Details Section */}
                                                                <Col md={4}>
                                                                        <h5>Customer Details</h5>
                                                                        <Row>
                                                                                <Col md={6}><p><strong>Lead Id:</strong> 12345</p></Col>
                                                                                <Col md={6}><p><strong>Name:</strong> John Doe</p></Col>
                                                                        </Row>
                                                                        <Row>
                                                                                <Col md={6}>
                                                                                        <p><strong><FaPhone /> </strong> +1 9876543210</p>
                                                                                </Col>
                                                                                <Col md={6}>
                                                                                        <p><strong><FaEnvelope /></strong> johndoe@example.com</p>
                                                                                </Col>
                                                                        </Row>

                                                                        <hr />
                                                                        <h5>Opportunity Details</h5>
                                                                        <h5>History</h5>

                                                                        {/* Accordion for History */}
                                                                        <Accordion defaultActiveKey="0">
                                                                                {/* Trip 1 - Goa */}
                                                                                <Accordion.Item eventKey="0">
                                                                                        <Accordion.Header>Booked Goa on Dec 25</Accordion.Header>
                                                                                        <Accordion.Body>
                                                                                                <Row>
                                                                                                        <Col md={6}><p><strong>Destination:</strong> Goa</p></Col>
                                                                                                        <Col md={6}><p><strong>Start Date:</strong> 25/12/2024</p></Col>
                                                                                                </Row>
                                                                                                <Row>
                                                                                                        <Col md={6}><p><strong>End Date:</strong> 30/12/2024</p></Col>
                                                                                                        <Col md={6}><p><strong>Duration:</strong> 5 days</p></Col>
                                                                                                </Row>
                                                                                                <Row>
                                                                                                        <Col md={6}><p><strong>Number of Adults:</strong> 3</p></Col>
                                                                                                        <Col md={6}><p><strong>Number of Children:</strong> 2</p></Col>
                                                                                                </Row>
                                                                                                <Row>
                                                                                                        <Col md={6}><p><strong>Child Age:</strong> 5 years</p></Col>
                                                                                                        <Col md={6}><p><strong>Approx Budget:</strong> $3000</p></Col>

                                                                                                </Row>

                                                                                                <Row>

                                                                                                        <Col md={12}><p><strong>Reminder Setting:</strong> 24/12/2024 10:00 AM</p></Col>
                                                                                                </Row>

                                                                                        </Accordion.Body>
                                                                                </Accordion.Item>

                                                                                {/* Trip 2 - Paris */}
                                                                                <Accordion.Item eventKey="1">
                                                                                        <Accordion.Header>Booked Paris on Oct 12</Accordion.Header>
                                                                                        <Accordion.Body>
                                                                                                <Row>
                                                                                                        <Col md={6}><p><strong>Destination:</strong> Paris</p></Col>
                                                                                                        <Col md={6}><p><strong>Start Date:</strong> 12/10/2024</p></Col>
                                                                                                </Row>
                                                                                                <Row>
                                                                                                        <Col md={6}><p><strong>End Date:</strong> 20/10/2024</p></Col>
                                                                                                        <Col md={6}><p><strong>Duration:</strong> 8 days</p></Col>
                                                                                                </Row>
                                                                                                <Row>
                                                                                                        <Col md={6}><p><strong>Number of Adults:</strong> 2</p></Col>
                                                                                                        <Col md={6}><p><strong>Number of Children:</strong> 1</p></Col>
                                                                                                </Row>
                                                                                                <Row>
                                                                                                        <Col md={6}><p><strong>Child Age:</strong> 4 years</p></Col>
                                                                                                        <Col md={6}><p><strong>Approx Budget:</strong> $5000</p></Col>

                                                                                                </Row>


                                                                                                <Row>

                                                                                                        <Col md={12}><p><strong>Reminder Setting:</strong> 11/10/2024 10:00 AM</p></Col>
                                                                                                </Row>
                                                                                        </Accordion.Body>
                                                                                </Accordion.Item>

                                                                                {/* Trip 3 - Bali */}
                                                                                <Accordion.Item eventKey="2">
                                                                                        <Accordion.Header>Booked Bali on Nov 15</Accordion.Header>
                                                                                        <Accordion.Body>
                                                                                                <Row>
                                                                                                        <Col md={6}><p><strong>Destination:</strong> Bali</p></Col>
                                                                                                        <Col md={6}><p><strong>Start Date:</strong> 15/11/2024</p></Col>
                                                                                                </Row>
                                                                                                <Row>
                                                                                                        <Col md={6}><p><strong>End Date:</strong> 22/11/2024</p></Col>
                                                                                                        <Col md={6}><p><strong>Duration:</strong> 7 days</p></Col>
                                                                                                </Row>
                                                                                                <Row>
                                                                                                        <Col md={6}><p><strong>Number of Adults:</strong> 4</p></Col>
                                                                                                        <Col md={6}><p><strong>Number of Children:</strong> 0</p></Col>
                                                                                                </Row>
                                                                                                <Row>
                                                                                                        <Col md={6}><p><strong>Child Age:</strong> 6 years</p></Col>

                                                                                                        <Col md={6}><p><strong>Approx Budget:</strong> $4000</p></Col>

                                                                                                </Row>


                                                                                                <Row>

                                                                                                        <Col md={12}><p><strong>Reminder Setting:</strong> 14/11/2024 09:00 AM</p></Col>
                                                                                                </Row>
                                                                                        </Accordion.Body>
                                                                                </Accordion.Item>
                                                                        </Accordion>
                                                                </Col>

                                                                
                                                                <Col md={4}>
                                                                        <h5>Additional Details</h5>
                                                                        <Accordion defaultActiveKey="0">
                                                                                {/* Status Actions */}
                                                                                <Accordion.Item eventKey="0">
                                                                                        <Accordion.Header>Status Actions</Accordion.Header>
                                                                                        <Accordion.Body>
                                                                                                <Form.Group className="mb-3">
                                                                                                        {/* <Form.Label><strong>Status Actions:</strong></Form.Label> */}
                                                                                                        <Dropdown>
                                                                                                                <Dropdown.Toggle variant="primary" id="status-actions">
                                                                                                                        Select Action
                                                                                                                </Dropdown.Toggle>
                                                                                                                <Dropdown.Menu>
                                                                                                                        <Dropdown.Item>Pending</Dropdown.Item>
                                                                                                                        <Dropdown.Item>In Progress</Dropdown.Item>
                                                                                                                        <Dropdown.Item>Completed</Dropdown.Item>
                                                                                                                </Dropdown.Menu>
                                                                                                        </Dropdown>
                                                                                                </Form.Group>
                                                                                        </Accordion.Body>
                                                                                </Accordion.Item>

                                                                                {/* Add Comment */}
                                                                                <Accordion.Item eventKey="1">
                                                                                        <Accordion.Header>Add Comment</Accordion.Header>
                                                                                        <Accordion.Body>
                                                                                                <Form.Group className="mb-3">
                                                                                                        {/* <Form.Label><strong>Add Comment:</strong></Form.Label> */}
                                                                                                        <Form.Control type="text" placeholder="Enter comment" />
                                                                                                </Form.Group>
                                                                                        </Accordion.Body>
                                                                                </Accordion.Item>

                                                                                {/* Add Payment */}
                                                                                <Accordion.Item eventKey="2">
                                                                                        <Accordion.Header>Add Payment</Accordion.Header>
                                                                                        <Accordion.Body>
                                                                                                <Form.Group className="mb-3">
                                                                                                        {/* <Form.Label><strong>Add Payment:</strong></Form.Label> */}
                                                                                                        <Form.Control type="number" placeholder="Enter amount" />
                                                                                                </Form.Group>
                                                                                        </Accordion.Body>
                                                                                </Accordion.Item>

                                                                                {/* Send Quote */}
                                                                                <Accordion.Item eventKey="3">
                                                                                        <Accordion.Header>Send Quote</Accordion.Header>
                                                                                        <Accordion.Body>
                                                                                                <Form.Group className="mb-3">
                                                                                                        {/* <Form.Label><strong>Send Quote:</strong></Form.Label> */}
                                                                                                        <Form.Control type="text" placeholder="Enter quote details" />
                                                                                                </Form.Group>
                                                                                        </Accordion.Body>
                                                                                </Accordion.Item>

                                                                                {/* Add Reminder */}
                                                                                <Accordion.Item eventKey="4">
                                                                                        <Accordion.Header>Add Reminder</Accordion.Header>
                                                                                        <Accordion.Body>
                                                                                                <Form.Group className="mb-3">
                                                                                                        {/* <Form.Label><strong>Add Reminder:</strong></Form.Label> */}
                                                                                                        <Form.Control type="datetime-local" />
                                                                                                </Form.Group>
                                                                                        </Accordion.Body>
                                                                                </Accordion.Item>

                                                                                {/* Submit Button */}
                                                                                <Accordion.Item eventKey="5">
                                                                                        <Accordion.Body>
                                                                                                <Button variant="success" className="w-100">Submit</Button>
                                                                                        </Accordion.Body>
                                                                                </Accordion.Item>
                                                                        </Accordion>

                                                                </Col>
                                                                <Col md={4}>
                                                                        <h5>Customer Interaction log</h5>
                                                                        <p><strong>Notes:</strong></p>
                                                                        <div className="s-Opp-Commentsection">
                                                                                <p>Customer prefers a luxury hotel with sea view.</p>
                                                                        </div>
                                                                        <p><strong>Comments:</strong></p>
                                                                        <div className="s-Opp-Commentsection">
                                                                                <p>no comments</p>
                                                                        </div>
                                                                </Col>
                                                        </Row>
                                                </Card.Body>
                                                <Card.Footer className="s-LeadOppView-footer">
                                                        <button className="btn btn-secondary">Back</button>
                                                        <button className="btn btn-primary">Edit</button>
                                                </Card.Footer>
                                        </Card>
                                </div>
                        </div>
                </div>
        );
};

export default LeadOppView;
