import React, { useState, useEffect, useContext } from "react";
import axios from "axios";
import DataTable from "./../../../Layout/Table/TableLayout"; // Ensure this path is correct
import Navbar from "../../../Shared/Sales-ExecutiveNavbar/Navbar";
import "./Customer.css";
import { FaEye, FaEdit, FaTrash } from "react-icons/fa";
import { baseURL } from "../../../Apiservices/Api";
import { AuthContext } from '../../../AuthContext/AuthContext';
import { useNavigate } from 'react-router-dom';

const SalesCustomer = () => {
  const [collapsed, setCollapsed] = useState(false);
  const [data, setData] = useState([]); // State for storing matched customer data
  const { authToken, userId } = useContext(AuthContext);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchCustomersAndLeads = async () => {
      try {
        // Fetch all leads
        const leadsResponse = await axios.get(`${baseURL}/api/allleads`, {
          headers: {
            Authorization: `Bearer ${authToken}`, // Include token if needed
          },
        });

        if (leadsResponse.status === 200) {
          const leadsData = leadsResponse.data;

          // Fetch all customers
          const customersResponse = await axios.get(`${baseURL}/api/customers`, {
            headers: {
              Authorization: `Bearer ${authToken}`, // Include token if needed
            },
          });

          if (customersResponse.status === 200) {
            const customersData = customersResponse.data;

            // Match customer IDs with leads
            const matchedCustomers = leadsData
              .filter(lead => lead.assignedSalesId == userId && lead.status == 'opportunity')
              .map(lead => {
                const customer = customersData.find(customer => customer.id == lead.customerid);
                return customer ? { ...customer, leadId: lead.id } : null; // Include leadId for actions
              })
              .filter(customer => customer !== null); // Remove null entries

            setData(matchedCustomers); // Update state with matched customer data
          } else {
            console.error("Error fetching customers:", customersResponse.statusText);
          }
        } else {
          console.error("Error fetching leads:", leadsResponse.statusText);
        }
      } catch (error) {
        console.error("Error fetching data:", error);
        alert("Failed to fetch data.");
      }
    };

    fetchCustomersAndLeads();
  }, [authToken, userId]);

  // const navigateToLead = (leadId) => {
  //   navigate(`/sales-details/${leadId}`, {
  //     state: { leadid: leadId },
  //   });
  // };

  const navigateToLead = (leadId) => {
    navigate(`/customerdetails/${leadId}`, {
      state: { leadid: leadId },
    });
  };

  // Columns for DataTable component
  const columns = React.useMemo(
    () => [
      {
        Header: "S.No",
        accessor: (row, index) => index + 1,  // This will generate the serial number based on the row index
      },
      {
        Header: "Customer ID",
        accessor: "id", // This is the key in your customer data
        Cell: ({ row }) => {
          const customerId = row.original.id; // Get the customer ID from the row
          return customerId !== undefined
            ? `CUS${String(customerId).padStart(4, '0')}` // Format the ID
            : "N/A"; // Fallback if ID is not available
        },
      },
      {
        Header: "Name",
        accessor: "name", // Ensure this matches the key in your customer data
      },
      {
        Header: "Mobile No",
        accessor: "phone_number", // Ensure this matches the key in your customer data
      },
      {
        Header: "Email",
        accessor: "email", // Ensure this matches the key in your customer data
      },
      // {
      //   Header: "Description",
      //   accessor: "description", // Ensure this matches the key in your customer data
      // },
      {
        Header: "Actions",
        accessor: "actions",
        Cell: ({ row }) => (
          <div>
            <button
              className="btn btn-primary btn-sm me-2"
              onClick={() => navigateToLead(row.original.leadId)} // Use leadId for navigation
            >
              <FaEye />
            </button>
            {/* Uncomment if you want to implement edit and delete actions
            <button
              className="btn btn-warning btn-sm me-2"
              onClick={() => editCustomer(row.original)}
            >
              <FaEdit />
            </button>
            <button
              className="btn btn-danger btn-sm"
              onClick={() => deleteCustomer(row.original.leadId)}
            >
              <FaTrash />
            </button>
            */}
          </div>
        ),
      },
    ],
    []
  );

  return (
    <div className="SaleCustomercontainer">
      <Navbar onToggleSidebar={setCollapsed} />
      <div className={`SaleCustomer ${collapsed ? "collapsed" : ""}`}>
        <div className="SaleCustomer-container mb-5">
          <div className="SaleCustomer-table-container">
            <h3 className="d-flex justify-content-between align-items-center">
              Customer Details
            </h3>
            <DataTable columns={columns} data={data} />
          </div>
        </div>
      </div>
    </div>
  );
};

export default SalesCustomer;